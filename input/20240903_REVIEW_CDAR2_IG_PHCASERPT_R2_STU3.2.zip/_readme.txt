This readme is included in a zip file that packages the errata package of:


Publication title:                               HL7 CDA� R2 Implementation Guide: Public Health Case Report, Release 2 - the Electronic Initial Case Report - STU Release 3.2 - US Realm
Edition:                                         Release 2 STU 3.2
Realm:                                           US Realm
Release status:                                  Standard for Trial Use (STU)
JIRA Specification key:                          phcaserpt
Version:                                         1.3.2
Errata identifier:                               ??????
Publication date:                                2024-09
Prepared by:                                     Public Health Work Group

The package was prepared by Lantana Consulting Group, LLC.

Contents of the package:
========================
_readme.txt                                                             								This file

CDAR2_IG_PHCASERPT_R2_STU3.2_Vol1_Introductory_Material.pdf                								Implementation Guide Introductory MaterialCDAR2_IG_PHCASERPT_R2_STU3.2_Vol2_Templates_and_Supporting.pdf             								Implementation Guide Template Library and Supporting Material
XML and Related files (Schematron, sample, html, stylesheet) are housed on the HL7 GitHub: https://github.com/HL7/CDA-phcaserpt-1.3.2 (???????) TODO - ALL GIT paths need to be updated once versioning is sorted out

https://github.com/HL7/CDA-phcaserpt-1.3.2/blob/main/examples/samples/CDAR2_IG_PHCASERPT_R2_STU3.2_SAMPLE.xml				Sample file
https://github.com/HL7/CDA-phcaserpt-1.3.2/blob/main/examples/samples/CDAR2_IG_PHCASERPT_R2_STU3.2_SAMPLE_EXTERNAL_ENCOUNTER.xml	Sample file to represent an external encounter
https://github.com/HL7/CDA-phcaserpt-1.3.2/blob/main/examples/samples/CDAR2_IG_PHCASERPT_R2_STU3.2_SAMPLE_MANUAL.xml			Sample file to represent a manual trigger

https://github.com/HL7/CDA-phcaserpt-1.3.2/blob/main/validation/CDAR2_IG_PHCASERPT_R2_STU3.2_SCHEMATRON.sch				Schematron file
https://github.com/HL7/CDA-phcaserpt-1.3.2/blob/main/validation/CDAR2_IG_PHCASERPT_R2_STU3.2_VOCABULARY.xml				Schematron vocabulary file

https://github.com/HL7/CDA-phcaserpt-1.3.2/blob/main/transform/CDAR2_eCR_eICR.xsl							Stylesheet for rendering


The latest CDA Schema is located on the HL7 GitHub site: https://github.com/HL7/cda-core-2.0/tree/master/schema/extensions/SDTC


Questions 
========================
Direct questions about the implementation guide to the HL7 Public Health Working Group.
                                
September 2024